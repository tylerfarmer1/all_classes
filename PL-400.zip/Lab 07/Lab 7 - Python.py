import requests
import json
from datetime import datetime


# You get this info from registering an App in Azure AD

client_id = '70459423-74a9-4a9c-86ef-5b60bfa78fc1'
client_secret = '9A68Q~y~XH~JqPO7S.ayhXJP96XnoGBj.i4JMa-f'
tenant_id = '5ed3ccff-c413-4a1a-bf64-3f3994daa128'


# NOTE: you also have to create an App User in the Environment!!!!


# This comes from the Model-driven app when you play it.
resource = 'https://orga62503ed.crm.dynamics.com'  # Your Dataverse instance URL
            

# Get the access token
def get_access_token(client_id, client_secret, tenant_id, resource):
    url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"
    payload = {
        'client_id': client_id,
        'client_secret': client_secret,
        'resource': resource,
        'grant_type': 'client_credentials'
    }
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    response = requests.post(url, data=payload, headers=headers)
    response.raise_for_status()  # Raise an error for bad status codes
    return response.json()['access_token']

# Get all rows from contoso_inspections table
def get_contoso_inspections(access_token, resource):
    
    # this version returns all rows from the Inspection table
    url = f"{resource}/api/data/v9.1/contoso_inspections"
    
    # this version only returns rows where the Inspection Status = Pending (code 330650001)
    statuscode_filter = 330650001
    url = f"{resource}/api/data/v9.1/contoso_inspections?$filter=statuscode eq {statuscode_filter}"
        
    # this one retrieve just some specific fields
    #url = f"{resource}/api/data/v9.2/contoso_inspections?$select=contoso_inspectionname,_contoso_permit_value,statuscode"
    
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Accept': 'application/json'
        
        # if you include this line, the data will include the "lookup" values instead of just GUIDs
        ,'Prefer' : 'odata.include-annotations="*"'
    }
    response = requests.get(url, headers=headers)
    response.raise_for_status()  # Raise an error for bad status codes
    return response.json()

# Main logic

access_token = get_access_token(client_id, client_secret, tenant_id, resource)

inspections = get_contoso_inspections(access_token, resource)



#print(inspections["value"][0])

# Print the retrieved rows
#print(json.dumps(inspections, indent=4))
#print(type(inspections))    # this is Dictionary
#print(len(inspections))     # this is length 2
#print(inspections.keys())   # These are ['@odata.context', 'value']


print("\n\n")
my_data = inspections["value"]    

# if you return all columns WITHOUT the "Prefer" in the header, these are the fields that are returned.
'''
{'@odata.etag': 'W/"1694014"', 
'contoso_inspectiontype': 330650000, 
'contoso_inspectionid': 'd90f60cd-c321-ef11-840a-0022482626f7', 
'_owningbusinessunit_value': '8a477db3-d41f-ef11-840a-0022481c2953', 
'statecode': 0, 
'statuscode': 330650002, 
'_createdby_value': '8d4e7db3-d41f-ef11-840a-0022481c2953', 
'contoso_inspectionname': 'Plumbing Inspection', 
'timezoneruleversionnumber': 4, 
'_ownerid_value': '8d4e7db3-d41f-ef11-840a-0022481c2953', 
'modifiedon': '2024-06-03T18:13:00Z', 
'_modifiedby_value': '8d4e7db3-d41f-ef11-840a-0022481c2953', 
'_owninguser_value': '8d4e7db3-d41f-ef11-840a-0022481c2953', 
'createdon': '2024-06-03T16:10:32Z', 
'versionnumber': 1694014, 
'contoso_scheduleddate': '2024-06-06T00:00:00Z', 
'_contoso_permit_value': 'dbd4b3d1-bc21-ef11-840a-0022482626f7', 
'contoso_sequence': None, 
'_stageid_value': None, 
'overriddencreatedon': None, 
'contoso_comments': None, 
'importsequencenumber': None, 
'_modifiedonbehalfby_value': None, 
'utcconversiontimezonecode': None, 
'processid': None, 
'_createdonbehalfby_value': None, 
'traversedpath': None, 
'_owningteam_value': None}
'''

one_row = my_data[0]    # stores the first record returned into one_row
print(one_row)    # this prints out the dictionary in "raw" form
'''
if you DON'T include the "Prefer" in the header, this is what you get back:

{'@odata.etag': 'W/"1689943"', 'contoso_inspectionname': 'Framing Inspection', 
'_contoso_permit_value': 'dbd4b3d1-bc21-ef11-840a-0022482626f7', 'statuscode': 330650001, 
'contoso_inspectionid': 'fad030e3-bc21-ef11-840a-0022482626f7'}

if you DO include the "Prefer" in the header, this is what you get back:

{'@odata.etag': 'W/"1689943"', 'contoso_inspectionname': 'Framing Inspection', 
'_contoso_permit_value@OData.Community.Display.V1.FormattedValue': 'Test Permit', 
'_contoso_permit_value@Microsoft.Dynamics.CRM.associatednavigationproperty': 'contoso_Permit', 
'_contoso_permit_value@Microsoft.Dynamics.CRM.lookuplogicalname': 'contoso_permit', 
'_contoso_permit_value': 'dbd4b3d1-bc21-ef11-840a-0022482626f7', 
'statuscode@OData.Community.Display.V1.FormattedValue': 'Pending', 
'statuscode': 330650001, 'contoso_inspectionid': 'fad030e3-bc21-ef11-840a-0022482626f7'}
'''
for key, value in one_row.items():
    print(f"Key: {key}, Value: {value}")

'''
if you DON'T include the "Prefer" in the header, this is what you get back:

Key: @odata.etag, Value: W/"1689943"
Key: contoso_inspectionname, Value: Framing Inspection
Key: _contoso_permit_value, Value: dbd4b3d1-bc21-ef11-840a-0022482626f7
Key: statuscode, Value: 330650001
Key: contoso_inspectionid, Value: fad030e3-bc21-ef11-840a-0022482626f7

if you DO include the "Prefer" in the header, this is what you get back:

Key: @odata.etag, Value: W/"1689943"
Key: contoso_inspectionname, Value: Framing Inspection
Key: _contoso_permit_value@OData.Community.Display.V1.FormattedValue, Value: Test Permit
Key: _contoso_permit_value@Microsoft.Dynamics.CRM.associatednavigationproperty, Value: contoso_Permit
Key: _contoso_permit_value@Microsoft.Dynamics.CRM.lookuplogicalname, Value: contoso_permit
Key: _contoso_permit_value, Value: dbd4b3d1-bc21-ef11-840a-0022482626f7
Key: statuscode@OData.Community.Display.V1.FormattedValue, Value: Pending
Key: statuscode, Value: 330650001
Key: contoso_inspectionid, Value: fad030e3-bc21-ef11-840a-0022482626f7

'''


# need to change the query to include the scheduled date for this to work.
# since the date is a string and it's formatted as UTC, use this function to an actual datetime object
#my_date = datetime.strptime(one_row['contoso_scheduleddate'], "%Y-%m-%dT%H:%M:%SZ")

# Format the date as xx/xx/xxxx
#formatted_date = f"{my_date.month:02d}/{my_date.day:02d}/{my_date.year:04d}"

#print(formatted_date)  # Output: 06/10/2024

