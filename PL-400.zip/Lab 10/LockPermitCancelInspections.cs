using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Text.RegularExpressions;

namespace ContosoPackageProject
{
    public class LockPermitCancelInspections : PluginBase
    {
        public LockPermitCancelInspections(string unsecureConfiguration, string secureConfiguration)
: base(typeof(PreOperationPermitCreate))
        {

        }

        protected override void ExecuteDataversePlugin(ILocalPluginContext localPluginContext)
        {
            if (localPluginContext == null)
            {
                throw new ArgumentNullException(nameof(localPluginContext));
            }

            var permitEntityRef = localPluginContext.PluginExecutionContext.InputParameters["Target"] as EntityReference;
            Entity permitEntity = new Entity(permitEntityRef.LogicalName, permitEntityRef.Id);
            
            // Anytime you see "LocalPluginContext.Trace" it is adding some information to a Trace Log 
            // which we'll see in the XRM Toolbox, a tool called "Plugin Trace Viewer"
            localPluginContext.Trace("Updating Permit Id : " + permitEntityRef.Id);
            
            // 330650001 referse to the "Locked" status on the Permit Table.   
            // You can verify that if you edit the "Permit Status" column on the Permit table.
            permitEntity["statuscode"] = new OptionSetValue(330650001);

            // This saves the data.
            localPluginContext.PluginUserService.Update(permitEntity);
            localPluginContext.Trace("Updated Permit Id " + permitEntityRef.Id);

            // Now we're building a Query string that gets all Inspections that have the same PermitID
            QueryExpression qe = new QueryExpression
            {
                EntityName = "contoso_inspection",
                ColumnSet = new ColumnSet("statuscode"),
            };
            qe.Criteria.AddCondition("contoso_permit", ConditionOperator.Equal, permitEntityRef.Id);

            localPluginContext.Trace("Retrieving inspections for Permit Id " + permitEntityRef.Id);
            var inspectionsResult = localPluginContext.PluginUserService.RetrieveMultiple(qe);
            localPluginContext.Trace("Retrieved " + inspectionsResult.Entities.Count + " inspection records");

            // This is a variable called "canceledInspectionsCount" and will keep track of how many Inspections are cancelled
            int canceledInspectionsCount = 0;
            
            // Loop through all of the Inspections that were retrieved.
            foreach (var inspection in inspectionsResult.Entities)
            {
                var currentValue = inspection.GetAttributeValue<OptionSetValue>("statuscode");
                // If the Inspection Status (statuscode) is either 1 (New Request) OR 330650001 (Pending)
                // then we'll set the Status to 330650004 (Canceled) and increment canceledInspectionsCount 
                if (currentValue.Value == 1 || currentValue.Value == 330650001)
                {
                    // increment the variable
                    canceledInspectionsCount++;  
                    // set the new status code
                    inspection["statuscode"] = new OptionSetValue(330650004); 
                    // log the start of updating the database
                    localPluginContext.Trace("Starting to Cancel inspection Id : " + inspection.Id);
                    // Save the inspection record
                    localPluginContext.PluginUserService.Update(inspection);
                    // log the Completion of updating the database
                    localPluginContext.Trace("Completed the Cancel of inspection Id : " + inspection.Id);
                }
            }

            if (canceledInspectionsCount > 0)
            {
                localPluginContext.Trace("There were " + canceledInspectionsCount + " inspection records that were Canceled.");
                // This the Output of the API.  In our solution this is the "Custom API Response Property" we created
                localPluginContext.PluginExecutionContext.OutputParameters["CanceledInspectionsCount"] = canceledInspectionsCount;
            }

            // This will add a "Note" on the Permit.  It will show up in the "Timeline" control on the main Permit form
            // It only does this if the "Reason" was submitted.
            // That comes from the "Custom API Request Parameter" that was created in our Solution
            if (localPluginContext.PluginExecutionContext.InputParameters.ContainsKey("Reason"))
            {
                localPluginContext.Trace("Building a note record");
                // This builds the Note record
                Entity note = new Entity("annotation");
                note["subject"] = "Permit Locked";
                note["notetext"] = "Reason for locking this permit: " + localPluginContext.PluginExecutionContext.InputParameters["Reason"];
                note["objectid"] = permitEntityRef;
                note["objecttypecode"] = permitEntityRef.LogicalName;

                localPluginContext.Trace("Creating a note record");
                // This saves the Note, and stores the GUID in createNoteId
                var createdNoteId = localPluginContext.PluginUserService.Create(note);

                if (createdNoteId != Guid.Empty){
                    localPluginContext.Trace("Note record was created.");
                }
                else {
                    localPluginContext.Trace("Note record was NOT created successfully.");
                }

            }
            else {
                localPluginContext.Trace("There was no Reason specified in the API Call, therefore a Note was not created");
            }
        }
    }
}
