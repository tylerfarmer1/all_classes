
// These 2 statements simply set up the Namespaces for "ContosoPermit" and "ContosoPermit.Scripts"
if (typeof (ContosoPermit) == "undefined") 
    { var ContosoPermit = { __namespace: true }; }

if (typeof (ContosoPermit.Scripts) == "undefined") 
    { ContosoPermit.Scripts = { __namespace: true }; }


// This will be the main name of the Library:  ContosoPermit.Scripts.PermitForm
ContosoPermit.Scripts.PermitForm = {

    // This will be in the "OnLoad" event of the Permit Form
    // the name will be ContosoPermit.Scripts.PermitForm.handleOnLoad
    handleOnLoad: function (executionContext) {
        "use strict";
        console.log('v1.0 - Starting the OnLoad Event - Permit Form');
        ContosoPermit.Scripts.PermitForm._handlePermitTypeSettings(executionContext);
    },


    // This will be in the "OnChange" event of the field called Permit Type
    // the name will be ContosoPermit.Scripts.PermitForm.handleOnChangePermitType
    handleOnChangePermitType: function (executionContext) {
        "use strict";
        console.log('Starting the OnChange Event - Permit Type');
        ContosoPermit.Scripts.PermitForm._handlePermitTypeSettings(executionContext);
    },


    // This is the actual code for *BOTH* the "OnLoad" event for the form
    // *AND* the "OnChange" event the Permit Type field
    // That's becuase we want the same code to execute when the form loads
    // and whenever the Permit Type changes.
    _handlePermitTypeSettings: function (executionContext) {
        "use strict";
        console.log('Starting handlePermitTypeSettings');
        
        var formContext = executionContext.getFormContext();
        
        // get the value of the permit type field
        var permitType = formContext.getAttribute("contoso_permittype").getValue();


        if (permitType == null) {
            // if the permit type is null, then we hide the Inspections tab, hide the New Size field
            // and also make New Size as not required.
            console.log('The Permit Type is Null.  Hiding Inspections tab and New Size field.');
            formContext.ui.tabs.get("inspectionsTab").setVisible(false);
            formContext.ui.controls.get("contoso_newsize").setVisible(false);
            formContext.getAttribute("contoso_newsize").setRequiredLevel("none");
            return;
        } else {
            // If we get here it's becase the Permit Type is NOT null
            // We have to retried that Permit Type from the table, and then determine if 
            // Inspection are required or not, and if the New Size is required or not.
            
            // This will be the GUID for the permit type that was selected in the form.
            var permitTypeID = permitType[0].id;
            console.log('The Permit Type GUID =' + permitTypeID);
            
            // Use the Xrm.Webapi to lookup that Permit Type ID in the table
            Xrm.WebApi.retrieveRecord("contoso_permittype", permitTypeID).then(function (result) {
                
                // This looks at the requireinspections field.
                // It will either show or hide that tab in the form.
                if (result.contoso_requireinspections) {
                    // If we get here, it means that Inspections are required, so show that tab
                    console.log('Inspections are required - showing the inspection tab');
                    formContext.ui.tabs.get("inspectionsTab").setVisible(true);
                } else {
                    // If we get here, it means that Inspections are NOT required, so hide that tab
                    console.log('Inspections are NOT required - hiding the inspection tab');
                    formContext.ui.tabs.get("inspectionsTab").setVisible(false);
                }

                // This looks at the requiresize field.
                // It will either show or hide that field on the form, and make it required
                if (result.contoso_requiresize) {
                    // If we get here, it means that New Size is required, so show that field 
                    // and make it required
                    console.log('New Size is required, showing that field');
                    formContext.ui.controls.get("contoso_newsize").setVisible(true);
                    formContext.getAttribute("contoso_newsize").setRequiredLevel("required");
                } else {
                    // If we get here, it means that New Size is NOT required, so hide that field 
                    // and make it NOT required
                    console.log('New Size is NOT required, hiding that field');
                    formContext.getAttribute("contoso_newsize").setRequiredLevel("none");
                    formContext.ui.controls.get("contoso_newsize").setVisible(false);
                }
            },

            function (error) { alert('Error:' + error.message) });
        }

    },

    
    // This is where we'll paste some additional code in a later lab (start)

    _lockPermitRequest: function (permitID, reason) {
        "use strict";
        console.log('Starting the _lockPermitRequest function');
        this.entity = { entityType: "contoso_permit", id: permitID };
        this.Reason = reason;
        this.getMetadata = function () {
            return {
                boundParameter: "entity", parameterTypes: {
                    "entity": {
                        typeName: "mscrm.contoso_permit",
                        structuralProperty: 5
                    },
                    "Reason": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1 // Primitive Type
                    }
                },
                operationType: 0, // This is an action. Use '1' for functions and '2' for CRUD
                operationName: "contoso_LockPermit",
            };
        };
    },

    lockPermit: function (primaryControl) {
        // This is what will be called when the Button is pushed in the App
        "use strict";        
        console.log('Starting the lockPermit function');
        var formContext = primaryControl;
        var PermitID = formContext.data.entity.getId().replace('{', '').replace('}', '');
        var lockPermitRequest = new ContosoPermit.Scripts.PermitForm._lockPermitRequest(PermitID, "Admin Lock");
        // Use the request object to execute the function
        Xrm.WebApi.online.execute(lockPermitRequest).then(
            function (result) {
                if (result.ok) {
                    console.log("Status: %s %s", result.status, result.statusText);
                    // perform other operations as required;
                    formContext.ui.setFormNotification("Status " + result.status, "INFORMATION");
                }
            },
            function (error) {
                console.log(error.message);
                // handle error conditions
            }
        );
    },

    // This is where we'll paste some additional code in a later lab (end)


    __namespace: true
}