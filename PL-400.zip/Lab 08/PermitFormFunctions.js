if (typeof (ContosoPermit) == "undefined") 
    { var ContosoPermit = { __namespace: true }; }

if (typeof (ContosoPermit.Scripts) == "undefined") 
    { ContosoPermit.Scripts = { __namespace: true }; }

ContosoPermit.Scripts.PermitForm = {

    handleOnLoad: function (executionContext) {
        "use strict";
        console.log('v1.0 - Starting the OnLoad Event - Permit Form');
        ContosoPermit.Scripts.PermitForm._handlePermitTypeSettings(executionContext);
    },

    handleOnChangePermitType: function (executionContext) {
        "use strict";
        console.log('Starting the OnChange Event - Permit Type');
        ContosoPermit.Scripts.PermitForm._handlePermitTypeSettings(executionContext);
    },

    _handlePermitTypeSettings: function (executionContext) {
        "use strict";
        console.log('Starting handlePermitTypeSettings');
        
        var formContext = executionContext.getFormContext();
        
        // get the value of the permit type field
        var permitType = formContext.getAttribute("contoso_permittype").getValue();


        if (permitType == null) {
            // if the permit type is null, then we hide the Inspections tab, hide the New Size field
            // and also make New Size as not required.
            console.log('The Permit Type is Null.  Hiding Inspections tab and New Size field.');
            formContext.ui.tabs.get("inspectionsTab").setVisible(false);
            formContext.ui.controls.get("contoso_newsize").setVisible(false);
            formContext.getAttribute("contoso_newsize").setRequiredLevel("none");
            return;
        } else {
            // If we get here it's becase the Permit Type is NOT null
            // We have to retried that Permit Type from the table, and then determine if 
            // Inspection are required or not, and if the New Size is required or not.
            
            // This will be the GUID for the permit type that was selected in the form.
            var permitTypeID = permitType[0].id;
            console.log('The Permit Type GUID =' + permitTypeID);
            
            // Use the Xrm.Webapi to lookup that Permit Type ID in the table
            Xrm.WebApi.retrieveRecord("contoso_permittype", permitTypeID).then(function (result) {
                
                // This looks at the requireinspections field.
                // It will either show or hide that tab in the form.
                if (result.contoso_requireinspections) {
                    // If we get here, it means that Inspections are required, so show that tab
                    console.log('Inspections are required - showing the inspection tab');
                    formContext.ui.tabs.get("inspectionsTab").setVisible(true);
                } else {
                    // If we get here, it means that Inspections are NOT required, so hide that tab
                    console.log('Inspections are NOT required - hiding the inspection tab');
                    formContext.ui.tabs.get("inspectionsTab").setVisible(false);
                }

                // This looks at the requiresize field.
                // It will either show or hide that field on the form, and make it required
                if (result.contoso_requiresize) {
                    // If we get here, it means that New Size is required, so show that field 
                    // and make it required
                    console.log('New Size is required, showing that field');
                    formContext.ui.controls.get("contoso_newsize").setVisible(true);
                    formContext.getAttribute("contoso_newsize").setRequiredLevel("required");
                } else {
                    // If we get here, it means that New Size is NOT required, so hide that field 
                    // and make it NOT required
                    console.log('New Size is NOT required, hiding that field');
                    formContext.getAttribute("contoso_newsize").setRequiredLevel("none");
                    formContext.ui.controls.get("contoso_newsize").setVisible(false);
                }
            },

            function (error) { alert('Error:' + error.message) });
        }

    },


    __namespace: true
}