import requests
import json
from datetime import datetime
import random
import sys

# You get this info from registering an App in Azure AD

client_id = '70459423-74a9-4a9c-86ef-5b60bfa78fc1'
client_secret = '9A68Q~y~XH~JqPO7S.ayhXJP96XnoGBj.i4JMa-f'
tenant_id = '5ed3ccff-c413-4a1a-bf64-3f3994daa128'
resource = 'https://org0264a703.crm.dynamics.com'  # Your Dataverse instance URL
            

# Get the access token
def get_access_token(client_id, client_secret, tenant_id, resource):
    url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"
    payload = {
        'client_id': client_id,
        'client_secret': client_secret,
        'resource': resource,
        'grant_type': 'client_credentials'
    }
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    
    response = requests.post(url, data=payload, headers=headers)
    response.raise_for_status()  # Raise an error for bad status codes
    return response.json()['access_token']

# Get all rows from contoso_inspections table
def get_contoso_inspections(access_token):
   
    base_url = "https://org0264a703.crm.dynamics.com"
    api_version = "9.1"
    table_name = "contoso_inspections"
    status_code_value = 330650001

    # Construct the Dataverse API URL
    url = f"{base_url}/api/data/v{api_version}/{table_name}?$filter=statuscode eq {status_code_value}"
    print(url)
    #sys.exit()
    # Set your Dataverse authentication token (replace with your actual token)
    headers = {
        'Authorization': f'Bearer {access_token}',
        "Content-Type": "application/json",
    }
    try:
        # Retrieve records
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            records = response.json()['value']
            
            for record in records:
                record_id = record['contoso_inspectionid']  
                
                new_value = str(random.randint(10, 90))
                update_url = f'{base_url}/api/data/v9.1/contoso_inspections({record_id})'
                
                payload = {'contoso_sequence': new_value}
                
                update_response = requests.patch(update_url, headers=headers, data=json.dumps(payload))

                if update_response.status_code == 204:
                    print(f'Record {record_id} updated successfully with contoso_sequence = {new_value}')
                else:
                    print(f'Failed to update record {record_id}: {update_response.status_code}, {update_response.text}')
        else:
            print(f'Failed to retrieve records: {response.status_code}, {response.text}')

    except Exception as e:
        print(f"Error: {str(e)}")


access_token = get_access_token(client_id, client_secret, tenant_id, resource)
get_contoso_inspections(access_token)
print("done")