AIBuilder Labs walks through Business Card reader, Category Classification, Document processing, EntityExtraction, Identity Document reader, Object Detection, Prediction, Receipt processing and Text Recognition scenarios.
Please visit [https://docs.microsoft.com/ai-builder/overview] to learn more about the scenarios and AIBuilder.

Please follow the steps below to set up the environment to use AIBuilder Labs 

For Category Classification, Entity Extraction, Object Detection, Prediction and Receipt Processing scenarios you need sample data in Dataverse.

Manual data Set up:
- Step 1 :Import AIBuilderLabSolution_1_0_0_1 solution to the Dataverse environment.
	This will create 5 Dataverse tables - Object Detection Product , Health Feedback, Online Shopping Intent, Travel feedback, Expenses

- Step 2 : Upload data to the tables created in step 1 
	Prediction : Please follow the instructions here[https://docs.microsoft.com/ai-builder/prediction-data-prep] to upload the Online Shopping Intent data.
	Category Classification : Go to Lab Data/CategoryClassification folder.Then upload data from pai_healthcare_feedbacks. Instructions here[https://docs.microsoft.com/ai-builder/before-you-build-text-classification-model]
	Entity Extraction : Go to Lab Data/EntityExtraction folder.Then upload data from aib_travelfeedback. Please follow the same instructions as above for data upload.

For Business Card reader, Document Processing, Identity Document reader, Object Detection, Receipt processing and Text Recognition Labs you will need images/pdfs which are available in the "Lab Images" folder.