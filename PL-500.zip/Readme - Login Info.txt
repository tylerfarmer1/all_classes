Your login information for the Power Platform is:

firstname.lastname@InterfaceTraining.com and the password is Pa55w.rd10




You will also have a "Shared Mailbox" that is named:

FundingFirstName@InterfaceTraining.com   like "FundingBob@InterfaceTraining.com"




For the Woodgrove Banking app and the Inspections web site, 
the username or account name can be anything, just use your first name.  
The password is "pass@word1".

The valid loan numbers in class are:
MC3747
JG7165
PS7765
NA5086



