Your login information for the Power Platform is:

firstname.lastname@InterfaceTraining.onmicrosoft.com

pa55w.rd10



You will also have a "Shared Mailbox" that is named:

Firsname-Shared@InterfaceTraining.onmicrosoft.com



