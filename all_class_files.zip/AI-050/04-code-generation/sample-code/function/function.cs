public static int AbsoluteSquare(int num1, int num2)
{
    int result = Math.Abs(num1 - num2);
    result *= result;
    return result;
}